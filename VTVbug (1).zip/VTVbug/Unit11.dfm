object Form11: TForm11
  Left = 0
  Top = 0
  Caption = 'Form11'
  ClientHeight = 440
  ClientWidth = 624
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  Position = poScreenCenter
  OnCreate = FormCreate
  DesignSize = (
    624
    440)
  TextHeight = 15
  object VirtualStringTree1: TVirtualStringTree
    Left = 0
    Top = 0
    Width = 624
    Height = 401
    Align = alTop
    Anchors = [akLeft, akTop, akRight, akBottom]
    ClipboardFormats.Strings = (
      'HTML Format'
      'Plain text'
      'Unicode text')
    Header.AutoSizeIndex = 0
    Header.Height = 15
    Header.Options = [hoAutoResize, hoColumnResize, hoDrag, hoShowSortGlyphs, hoVisible, hoAutoSpring]
    TabOrder = 0
    TreeOptions.PaintOptions = [toShowButtons, toShowDropmark, toShowHorzGridLines, toShowVertGridLines, toThemeAware, toUseBlendedImages, toFullVertGridLines]
    TreeOptions.SelectionOptions = [toFullRowSelect, toMultiSelect, toSimpleDrawSelection, toSelectNextNodeOnRemoval]
    OnGetText = VirtualStringTree1GetText
    Touch.InteractiveGestures = [igPan, igPressAndTap]
    Touch.InteractiveGestureOptions = [igoPanSingleFingerHorizontal, igoPanSingleFingerVertical, igoPanInertia, igoPanGutter, igoParentPassthrough]
    Columns = <
      item
        Position = 0
        Text = ' Column 1'
        Width = 520
      end
      item
        Position = 1
        Text = 'Column 2'
        Width = 100
      end>
  end
  object Button1: TButton
    Left = 511
    Top = 407
    Width = 113
    Height = 25
    Anchors = [akRight, akBottom]
    Caption = 'Copy to clipboard'
    TabOrder = 1
    OnClick = Button1Click
  end
end
